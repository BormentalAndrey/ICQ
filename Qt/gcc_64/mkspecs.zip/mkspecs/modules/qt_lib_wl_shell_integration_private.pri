QT.wl_shell_integration_private.VERSION = 6.5.0
QT.wl_shell_integration_private.name = QtWlShellIntegration
QT.wl_shell_integration_private.module = Qt6WlShellIntegration
QT.wl_shell_integration_private.libs = $$QT_MODULE_LIB_BASE
QT.wl_shell_integration_private.ldflags = 
QT.wl_shell_integration_private.includes = $$QT_MODULE_INCLUDE_BASE $$QT_MODULE_INCLUDE_BASE/QtWlShellIntegration $$QT_MODULE_INCLUDE_BASE/QtWlShellIntegration/6.5.0 $$QT_MODULE_INCLUDE_BASE/QtWlShellIntegration/6.5.0/QtWlShellIntegration
QT.wl_shell_integration_private.frameworks = 
QT.wl_shell_integration_private.bins = $$QT_MODULE_BIN_BASE
QT.wl_shell_integration_private.depends =  
QT.wl_shell_integration_private.run_depends = gui_private waylandclient_private
QT.wl_shell_integration_private.uses = 
QT.wl_shell_integration_private.module_config = v2 internal_module
QT.wl_shell_integration_private.DEFINES = QT_WL_SHELL_INTEGRATION_LIB
QT.wl_shell_integration_private.enabled_features = 
QT.wl_shell_integration_private.disabled_features = 
QT_CONFIG += 
QT_MODULES += wl_shell_integration_private

