QMAKE_INCDIR_LIBPNG = /Users/qt/work/qt/qtbase/src/3rdparty/libpng
QMAKE_DEFINES_LIBPNG = 
QMAKE_LIBS_LIBPNG = $$[QT_INSTALL_LIBS/get]/libQt6BundledLibpng_arm64-v8a.a
