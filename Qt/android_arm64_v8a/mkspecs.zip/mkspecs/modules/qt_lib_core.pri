QT.core.VERSION = 6.5.0
QT.core.name = QtCore
QT.core.module = Qt6Core
QT.core.libs = $$QT_MODULE_LIB_BASE
QT.core.ldflags = 
QT.core.includes = $$QT_MODULE_INCLUDE_BASE $$QT_MODULE_INCLUDE_BASE/QtCore
QT.core.frameworks = 
QT.core.bins = $$QT_MODULE_BIN_BASE
QT.core.depends =  
QT.core.uses = libatomic
QT.core.module_config = v2
QT.core.CONFIG = moc resources
QT.core.DEFINES = QT_CORE_LIB
QT.core.enabled_features = clock-monotonic doubleconversion cxx11_future cxx17_filesystem eventfd inotify std-atomic64 mimetype regularexpression sharedmemory shortcut systemsemaphore xmlstream xmlstreamreader xmlstreamwriter textdate datestring process processenvironment temporaryfile library settings filesystemwatcher filesystemiterator itemmodel proxymodel sortfilterproxymodel identityproxymodel transposeproxymodel concatenatetablesproxymodel stringlistmodel translation easingcurve animation gestures jalalicalendar islamiccivilcalendar timezone commandlineparser cborstreamreader cborstreamwriter permissions threadsafe-cloexec shared cross_compile appstore-compliant c++11 c++14 c++17 c++1z c99 c11 signaling_nan thread future concurrent opensslv30 shared cross_compile shared c++11 c++14 c++17 c++1z reduce_exports openssl
QT.core.disabled_features = glib cpp-winrt static pkg-config debug_and_release separate_debug_info simulator_and_device rpath force_asserts framework c++20 c++2a c++2b c++2b reduce_relocations wasm-simd128 wasm-exceptions zstd dbus openssl-linked opensslv11
QT_CONFIG += clock-monotonic doubleconversion cxx11_future cxx17_filesystem eventfd inotify std-atomic64 mimetype regularexpression sharedmemory shortcut systemsemaphore xmlstream xmlstreamreader xmlstreamwriter textdate datestring process processenvironment temporaryfile library settings filesystemwatcher filesystemiterator itemmodel proxymodel sortfilterproxymodel identityproxymodel transposeproxymodel concatenatetablesproxymodel stringlistmodel translation easingcurve animation gestures jalalicalendar islamiccivilcalendar timezone commandlineparser cborstreamreader cborstreamwriter permissions threadsafe-cloexec shared cross_compile appstore-compliant c++11 c++14 c++17 c++1z c99 c11 signaling_nan thread future concurrent opensslv30 shared cross_compile shared c++11 c++14 c++17 c++1z reduce_exports openssl
QT_MODULES += core

