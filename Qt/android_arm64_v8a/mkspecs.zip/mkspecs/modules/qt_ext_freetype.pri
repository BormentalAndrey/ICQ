QMAKE_INCDIR_FREETYPE = /Users/qt/work/qt/qtbase/src/3rdparty/freetype/include
QMAKE_DEFINES_FREETYPE = 
QMAKE_LIBS_FREETYPE = $$[QT_INSTALL_LIBS/get]/libQt6BundledFreetype_arm64-v8a.a
