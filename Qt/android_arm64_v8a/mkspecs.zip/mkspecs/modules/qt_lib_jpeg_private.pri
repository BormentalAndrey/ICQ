QT.jpeg_private.VERSION = 6.5.0
QT.jpeg_private.name = QtJpeg
QT.jpeg_private.module = 
QT.jpeg_private.libs = $$QT_MODULE_LIB_BASE
QT.jpeg_private.ldflags = 
QT.jpeg_private.includes = $$QT_MODULE_INCLUDE_BASE $$QT_MODULE_INCLUDE_BASE/QtJpeg $$QT_MODULE_INCLUDE_BASE/QtJpeg/6.5.0 $$QT_MODULE_INCLUDE_BASE/QtJpeg/6.5.0/QtJpeg
QT.jpeg_private.frameworks = 
QT.jpeg_private.bins = $$QT_MODULE_BIN_BASE
QT.jpeg_private.depends =  
QT.jpeg_private.uses = 
QT.jpeg_private.module_config = v2 internal_module
QT.jpeg_private.CONFIG = no_link
QT.jpeg_private.DEFINES = QT_JPEG_LIB
QT.jpeg_private.enabled_features = 
QT.jpeg_private.disabled_features = 
QT_CONFIG += 
QT_MODULES += jpeg_private

