QMAKE_INCDIR_LIBJPEG = /Users/qt/work/qt/qtbase/src/3rdparty/libjpeg/src
QMAKE_DEFINES_LIBJPEG = 
QMAKE_LIBS_LIBJPEG = $$[QT_INSTALL_LIBS/get]/libQt6BundledLibjpeg_arm64-v8a.a
