QT.quickcontrolstestutilsprivate_private.VERSION = 6.5.0
QT.quickcontrolstestutilsprivate_private.name = QtQuickControlsTestUtils
QT.quickcontrolstestutilsprivate_private.module = Qt6QuickControlsTestUtils
QT.quickcontrolstestutilsprivate_private.libs = $$QT_MODULE_LIB_BASE
QT.quickcontrolstestutilsprivate_private.ldflags = 
QT.quickcontrolstestutilsprivate_private.includes = $$QT_MODULE_INCLUDE_BASE $$QT_MODULE_INCLUDE_BASE/QtQuickControlsTestUtils $$QT_MODULE_INCLUDE_BASE/QtQuickControlsTestUtils/6.5.0 $$QT_MODULE_INCLUDE_BASE/QtQuickControlsTestUtils/6.5.0/QtQuickControlsTestUtils
QT.quickcontrolstestutilsprivate_private.frameworks = 
QT.quickcontrolstestutilsprivate_private.bins = $$QT_MODULE_BIN_BASE
QT.quickcontrolstestutilsprivate_private.depends =  core testlib qml qml_private quick quickcontrols2 quickdialogs2quickimpl_private quick_private quicktemplates2 quicktemplates2_private quicktestutilsprivate_private
QT.quickcontrolstestutilsprivate_private.uses = 
QT.quickcontrolstestutilsprivate_private.module_config = v2 internal_module staticlib
QT.quickcontrolstestutilsprivate_private.DEFINES = QT_QUICKCONTROLSTESTUTILSPRIVATE_LIB
QT.quickcontrolstestutilsprivate_private.enabled_features = 
QT.quickcontrolstestutilsprivate_private.disabled_features = 
QT_CONFIG += 
QT_MODULES += quickcontrolstestutilsprivate_private

